require('./models');
const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const mongoSanitize = require('express-mongo-sanitize');
const xss = require('xss-clean');
const hpp = require('hpp');
const cookieParser = require('cookie-parser');
const path = require('path');
const logger = require('./utils/logger');
const donationRouter = require('./routes/donationRoutes');
app.use('/api/v1/donate', donationRouter);
const app = express();

// Debug paths
console.log('Current directory:', process.cwd());
console.log('Routes directory:', path.resolve(__dirname, './routes'));
console.log('Controllers directory:', path.resolve(__dirname, './controllers'));

// 1. Global Middlewares
app.use(cors({ origin: process.env.CLIENT_URL, credentials: true }));
app.use(helmet());
app.use(express.json({ limit: '10kb' }));
app.use(cookieParser());
app.use(mongoSanitize());
app.use(xss());
app.use(hpp());

// Rate limiting
const limiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 1000, // limit each IP to 1000 requests per windowMs
  message: 'Too many requests from this IP, please try again later'
});
app.use('/api', limiter);

// 2. Routes
app.use('/api/v1/contact', require('./routes/contactRoutes'));
app.use('/api/v1/donate', require('./routes/donationRoutes')); // Only declare once
app.use('/api/v1/programs', require('./routes/programRoutes'));
app.use('/api/v1/volunteer', require('./routes/volunteerRoutes'));

// 3. Static files
app.use(express.static(path.join(__dirname, 'public')));

// 4. Error handling
app.use(require('./middlewares/errorMiddleware'));

module.exports = app;