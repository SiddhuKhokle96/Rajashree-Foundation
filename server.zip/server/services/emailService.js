const nodemailer = require('nodemailer');

const transporter = nodemailer.createTransport({
  service: 'Gmail',
  auth: {
    user: process.env.EMAIL_USER,
    pass: process.env.EMAIL_PASS
  }
});

module.exports = {
  sendDonationReceipt: async (donation) => {
    await transporter.sendMail({
      to: donation.donorEmail,
      subject: 'Donation Received',
      html: `<h1>Thank you for donating ₹${donation.amount}</h1>`
    });
  }
};

// In routes/donations.js
const { sendDonationReceipt } = require('../services/emailService');
router.post('/', async (req, res) => {
  const donation = await Donation.create();
  await sendDonationReceipt(donation);
});