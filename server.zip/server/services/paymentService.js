// services/paymentService.js
const Razorpay = require('razorpay');

const instance = new Razorpay({
  key_id: process.env.RAZORPAY_KEY,
  key_secret: process.env.RAZORPAY_SECRET
});

module.exports = {
  createOrder: async (amount) => {
    return await instance.orders.create({
      amount: amount * 100,
      currency: "INR"
    });
  }
};

// In routes/donations.js
const { createOrder } = require('../services/paymentService');
router.post('/create-order', auth, async (req, res) => {
  const order = await createOrder(req.body.amount);
  res.json(order);
});