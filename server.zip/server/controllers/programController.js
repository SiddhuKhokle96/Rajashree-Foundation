const mongoose = require('mongoose');

const programSchema = new mongoose.Schema({
  name: {
    type: String,
    required: [true, 'A program must have a name'],
    unique: true,
    trim: true
  },
  description: {
    type: String,
    required: [true, 'A program must have a description']
  },
  startDate: {
    type: Date,
    required: [true, 'A program must have a start date']
  },
  endDate: Date,
  location: {
    type: {
      type: String,
      default: 'Point',
      enum: ['Point']
    },
    coordinates: [Number],
    address: String,
    description: String
  },
  targetBeneficiaries: [String],
  budget: Number,
  status: {
    type: String,
    enum: ['planned', 'active', 'completed', 'cancelled'],
    default: 'planned'
  },
  createdBy: {
    type: mongoose.Schema.ObjectId,
    ref: 'User'
  },
  coverImage: String,
  gallery: [String],
  beneficiaries: [{
    type: mongoose.Schema.ObjectId,
    ref: 'Beneficiary'
  }],
  volunteers: [{
    type: mongoose.Schema.ObjectId,
    ref: 'User'
  }],
  createdAt: {
    type: Date,
    default: Date.now()
  }
});

programSchema.index({ location: '2dsphere' });

const Program = mongoose.model('Program', programSchema);

module.exports = Program;