const Donation = require('../models');
const logger = require('../utils/logger');
const Email = require('../utils/email');

exports.createDonation = async (req, res, next) => {
  try {
    const donation = await Donation.create(req.body);
    
    await new Email(
      donation.donorInfo,
      'donation-receipt',
      { amount: donation.amount }
    ).sendThankYou();

    res.status(201).json({
      success: true,
      data: donation
    });
  } catch (err) {
    logger.error(`Donation error: ${err.message}`);
    next(err);
  }
};

exports.getAllDonations = async (req, res, next) => {
  try {
    const donations = await Donation.findAll({
      order: [['createdAt', 'DESC']]
    });
    
    res.status(200).json({
      success: true,
      count: donations.length,
      data: donations
    });
  } catch (err) {
    next(err);
  }
};

exports.getDonation = async (req, res, next) => {
  try {
    const donation = await Donation.findByPk(req.params.id);
    
    if (!donation) {
      return res.status(404).json({
        success: false,
        message: 'Donation not found'
      });
    }
    
    res.status(200).json({
      success: true,
      data: donation
    });
  } catch (err) {
    next(err);
  }
};

exports.updateDonation = async (req, res, next) => {
  try {
    const [updated] = await Donation.update(req.body, {
      where: { id: req.params.id },
      returning: true
    });
    
    if (!updated) {
      return res.status(404).json({
        success: false,
        message: 'Donation not found'
      });
    }
    
    const donation = await Donation.findByPk(req.params.id);
    res.status(200).json({
      success: true,
      data: donation
    });
  } catch (err) {
    next(err);
  }
};