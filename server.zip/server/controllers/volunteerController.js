const Volunteer = require('../models/Volunteer');
const logger = require('../utils/logger');
const Email = require('../utils/email');

// @desc    Apply to become a volunteer
// @route   POST /api/v1/volunteer
// @access  Public
exports.createVolunteer = async (req, res, next) => {
  try {
    const volunteer = await Volunteer.create(req.body);
    
    // Send confirmation email
    await new Email(
      volunteer.personalInfo,
      'volunteer-application'
    ).sendApplicationConfirmation();
    
    res.status(201).json({
      success: true,
      data: volunteer
    });
  } catch (err) {
    logger.error(`Volunteer application error: ${err.message}`);
    next(err);
  }
};

// @desc    Get all volunteers (admin only)
// @route   GET /api/v1/volunteer
// @access  Private/Admin
exports.getAllVolunteers = async (req, res, next) => {
  try {
    const volunteers = await Volunteer.find().sort({ applicationDate: -1 });
    res.status(200).json({
      success: true,
      count: volunteers.length,
      data: volunteers
    });
  } catch (err) {
    next(err);
  }
};

// @desc    Get single volunteer
// @route   GET /api/v1/volunteer/:id
// @access  Private/Admin
exports.getVolunteer = async (req, res, next) => {
  try {
    const volunteer = await Volunteer.findById(req.params.id);
    
    if (!volunteer) {
      return res.status(404).json({
        success: false,
        message: 'Volunteer not found'
      });
    }
    
    res.status(200).json({
      success: true,
      data: volunteer
    });
  } catch (err) {
    next(err);
  }
};

// @desc    Update volunteer status
// @route   PATCH /api/v1/volunteer/:id
// @access  Private/Admin
exports.updateVolunteerStatus = async (req, res, next) => {
  try {
    const { status } = req.body;
    const volunteer = await Volunteer.findByIdAndUpdate(
      req.params.id,
      { status },
      { new: true, runValidators: true }
    );
    
    if (!volunteer) {
      return res.status(404).json({
        success: false,
        message: 'Volunteer not found'
      });
    }
    
    // Send status update email if status changed
    if (status !== volunteer.status) {
      await new Email(
        volunteer.personalInfo,
        'volunteer-status-update',
        { status }
      ).sendStatusUpdate();
    }
    
    res.status(200).json({
      success: true,
      data: volunteer
    });
  } catch (err) {
    next(err);
  }
};