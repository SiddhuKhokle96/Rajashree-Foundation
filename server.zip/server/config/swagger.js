module.exports = {
    definition: {
      openapi: '3.0.0',
      info: {
        title: 'Rajashree Foundation API',
        version: '1.0.0',
      },
    },
    apis: ['./routes/*.js'], // Path to your route files
  };