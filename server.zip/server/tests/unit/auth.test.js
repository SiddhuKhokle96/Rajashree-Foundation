const { validatePassword } = require('../../middleware/auth');

describe('Password Validation', () => {
  it('should reject passwords shorter than 8 chars', () => {
    expect(validatePassword('abc123')).toBe(false);
  });

  it('should accept valid passwords', () => {
    expect(validatePassword('SecurePass123!')).toBe(true);
  });
});