const { calculateDonationFee } = require('../../services/donations');

test('Calculates 2% fee correctly', () => {
  expect(calculateDonationFee(1000)).toBe(20); // 2% of 1000
});