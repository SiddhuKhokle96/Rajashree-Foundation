module.exports = {
    testUser: {
      name: "Test User",
      email: "test@example.com",
      password: "testPassword123"
    },
    testDonation: {
      amount: 500,
      donorEmail: "donor@example.com"
    }
  };