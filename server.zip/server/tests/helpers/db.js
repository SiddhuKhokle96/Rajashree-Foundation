const { sequelize } = require('../../models');

module.exports = {
  setupDB: async () => {
    await sequelize.sync({ force: true });
    // Optional: Seed test data here
  },
  cleanupDB: async () => {
    await sequelize.close();
  }
};