const { sequelize } = require('../../models');

module.exports = {
  setupDB: async () => {
    // Run migrations and seed test data
    await sequelize.sync({ force: true });
    // Add any test data here
  },
  teardownDB: async () => {
    await sequelize.close();
  }
};