const request = require('supertest');
const app = require('../../server/app');
const { setupDB } = require('../helpers/db');

describe('Auth API', () => {
  beforeAll(async () => {
    await setupDB();
  });

  test('POST /register - should create user', async () => {
    const res = await request(app)
      .post('/api/auth/register')
      .send({
        name: 'Test User',
        email: 'test@example.com',
        password: 'Password123!'
      });
      
    expect(res.statusCode).toBe(201);
    expect(res.body).toHaveProperty('token');
  });
});