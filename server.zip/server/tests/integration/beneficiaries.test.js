const request = require('supertest');
const app = require('../../server');

describe('Beneficiaries API', () => {
  let authToken;

  beforeAll(async () => {
    // Login to get token
    const res = await request(app)
      .post('/api/auth/login')
      .send({ email: 'admin@example.com', password: 'adminPass' });
    authToken = res.body.token;
  });

  it('GET /api/beneficiaries - requires auth', async () => {
    const res = await request(app)
      .get('/api/beneficiaries')
      .set('Authorization', `Bearer ${authToken}`);
    
    expect(res.statusCode).toEqual(200);
    expect(Array.isArray(res.body)).toBeTruthy();
  });
});