// middleware/roles.js
module.exports = (allowedRoles) => {
    return (req, res, next) => {
      if (!allowedRoles.includes(req.user.role)) {
        return res.status(403).json({ error: 'Forbidden' });
      }
      next();
    };
  };
  
  // In routes/beneficiaries.js
  const { ADMIN, MANAGER } = require('../constants/roles');
  router.delete('/:id', auth, roles([ADMIN]), (req, res) => { });