const nodemailer = require('nodemailer');
const logger = require('./logger');
const fs = require('fs');
const path = require('path');
const handlebars = require('handlebars');

class Email {
  constructor(user, type, data = {}) {
    this.to = user.email;
    this.name = user.name;
    this.from = `Rajshree Foundation <${process.env.EMAIL_FROM}>`;
    this.type = type;
    this.data = data;
    
    // Register partials
    this.registerPartials();
  }

  registerPartials() {
    const partialsDir = path.join(__dirname, '../email-templates/partials');
    const filenames = fs.readdirSync(partialsDir);
    
    filenames.forEach(filename => {
      const matches = /^([^.]+).hbs$/.exec(filename);
      if (!matches) return;
      
      const name = matches[1];
      const template = fs.readFileSync(path.join(partialsDir, filename), 'utf8');
      handlebars.registerPartial(name, template);
    });
  }

  newTransport() {
    if (process.env.NODE_ENV === 'production') {
      // Sendgrid for production
      return nodemailer.createTransport({
        service: 'SendGrid',
        auth: {
          user: process.env.SENDGRID_USERNAME,
          pass: process.env.SENDGRID_PASSWORD
        }
      });
    }

    // Mailtrap for development
    return nodemailer.createTransport({
      host: process.env.EMAIL_HOST,
      port: process.env.EMAIL_PORT,
      auth: {
        user: process.env.EMAIL_USERNAME,
        pass: process.env.EMAIL_PASSWORD
      }
    });
  }

  async loadTemplate(templateName) {
    const templatePath = path.join(__dirname, `../email-templates/${templateName}.hbs`);
    const source = fs.readFileSync(templatePath, 'utf8');
    return handlebars.compile(source);
  }

  async send() {
    try {
      // 1) Load template
      const template = await this.loadTemplate(this.type);
      
      // 2) Render HTML based on template
      const html = template({
        name: this.name,
        ...this.data
      });

      // 3) Define email options
      const mailOptions = {
        from: this.from,
        to: this.to,
        subject: this.getSubject(),
        html,
        text: this.getText()
      };

      // 4) Create transport and send email
      await this.newTransport().sendMail(mailOptions);
    } catch (err) {
      logger.error(`Email sending error: ${err.message}`);
      throw err;
    }
  }

  getSubject() {
    const subjects = {
      'donation-receipt': 'Thank You for Your Generous Donation',
      'volunteer-application': 'Volunteer Application Received',
      'volunteer-status-update': 'Volunteer Application Update',
      'contact-acknowledgment': 'Thank You for Contacting Us',
      'admin-notification': 'New Action Required'
    };
    return subjects[this.type] || 'Message from Rajshree Foundation';
  }

  getText() {
    // Fallback text version if HTML rendering fails
    const messages = {
      'donation-receipt': `Dear ${this.name},\n\nThank you for your donation of ${this.data.amount} to Rajshree Foundation.`,
      'volunteer-application': `Dear ${this.name},\n\nWe've received your volunteer application.`,
      'contact-acknowledgment': `Dear ${this.name},\n\nThank you for contacting Rajshree Foundation.`
    };
    return messages[this.type] || 'Thank you for your support.';
  }

  // Specific email methods
  async sendThankYou() {
    await this.send();
  }

  async sendApplicationConfirmation() {
    await this.send();
  }

  async sendStatusUpdate() {
    await this.send();
  }

  async sendContactAcknowledgment() {
    await this.send();
  }

  async sendAdminNotification() {
    this.to = process.env.ADMIN_EMAIL;
    await this.send();
  }
}

module.exports = Email;