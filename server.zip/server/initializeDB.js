require('dotenv').config();
const path = require('path');

console.log('Current directory:', __dirname);

// Adjust this path as needed
const { sequelize } = require('./server/models');

async function initialize() {
  try {
    console.log('Starting database initialization...');
    await sequelize.authenticate();
    console.log('Connection established');
    
    await sequelize.sync({ alter: true });
    console.log('Models synchronized');
    
    process.exit(0);
  } catch (err) {
    console.error('Initialization failed:', err);
    process.exit(1);
  }
}

initialize();